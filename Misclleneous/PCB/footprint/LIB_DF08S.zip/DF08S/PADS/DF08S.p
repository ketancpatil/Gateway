*PADS-LIBRARY-PART-TYPES-V9*

DF08S SOT508P985X260-4N I ANA 6 1 0 0 0
TIMESTAMP 2024.10.08.17.58.10
"Mouser Part Number" 512-DF08S
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi-Fairchild/DF08S?qs=Ec0VQc59F%252BlRA0XgpNiCJg%3D%3D
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" DF08S
"Description" DF08S, Bridge Rectifier Single Phase, 1.5A 800V, 4-Pin SDIP
"Datasheet Link" http://componentsearchengine.com/Datasheets/1/DF08S.pdf
GATE 1 4 0
DF08S
1 0 U OUT+
2 0 U OUT-
3 0 U AC
4 0 U AC_2

*END*
*REMARK* SamacSys ECAD Model
2691/210989/2.50/4/0/Undefined or Miscellaneous
