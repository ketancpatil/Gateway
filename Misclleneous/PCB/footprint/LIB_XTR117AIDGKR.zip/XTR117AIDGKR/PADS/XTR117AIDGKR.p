*PADS-LIBRARY-PART-TYPES-V9*

XTR117AIDGKR SOP65P490X110-8N I ANA 7 1 0 0 0
TIMESTAMP 2024.10.08.17.30.18
"Mouser Part Number" 595-XTR117AIDGKR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/XTR117AIDGKR?qs=zqbRmZ%252BfZD%252BYMdmF%252BmhQwg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" XTR117AIDGKR
"Description" Sensor Interface XTR117 4-20mA Crnt Loop Transmitter
"Datasheet Link" http://www.ti.com/lit/ds/symlink/xtr117.pdf
"Geometry.Height" 1.1mm
GATE 1 8 0
XTR117AIDGKR
1 0 U NC
2 0 U IIN
3 0 U IRET
4 0 U IO
8 0 U VREG
7 0 U V+
6 0 U B_(BASE)
5 0 U E_(EMITTER)

*END*
*REMARK* SamacSys ECAD Model
250048/210989/2.50/8/3/Integrated Circuit
